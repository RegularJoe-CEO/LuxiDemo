"""Luxi inference receipts v1 (Nov 8 2026).

Format ported from LuxiQuant Risk Runtime src/receipt.rs (same rules, new scheme name):
  payload  = scheme line + one "key=value" line per field, keys sorted (BTreeMap order), trailing newline;
             keys may not contain '=' or newline, values may not contain newline.
  receipt  = "lxir1_" + base64url_nopad(b"LXI" + version byte + 0 + Ed25519 public key (32) + signature (64))  (101 bytes)
  chain    = every receipt names its parent by parent_receipt_sha256 = sha256(parent payload) ("" for the first).
Step commitments: a Merkle tree (RFC 6962 hashing: leaf = sha256(0x00 || data), node = sha256(0x01 || left || right))
over one leaf per generated token: (row, step, token, 64-bit logit fingerprint). Inclusion proofs let a checker confirm
one step without the whole transcript, and comparing two transcripts' leaves finds the first step where they differ.
A signature binds the payload to a key. It does not prove the signer ran the model; independent replay does that.
"""
import base64, hashlib, json
from nacl.signing import SigningKey, VerifyKey
from nacl.exceptions import BadSignatureError

SCHEME = 'luxi-inference-receipt-v1'
PREFIX = 'lxir1_'
MAGIC = b'LXI'
BLOB_VERSION = 1


def h(b):
    return hashlib.sha256(b).hexdigest()


def cj(x):
    """canonical JSON bytes (sorted keys, no spaces)"""
    return json.dumps(x, sort_keys=True, separators=(',', ':')).encode()


def canonical_payload(fields):
    lines = [SCHEME]
    for k in sorted(fields):
        v = str(fields[k])
        if '=' in k or '\n' in k or not k:
            raise ValueError(f'illegal key {k}')
        if '\n' in v:
            raise ValueError(f'newline in {k}')
        lines.append(f'{k}={v}')
    return '\n'.join(lines) + '\n'


def parse_payload(payload):
    ls = payload.split('\n')
    if ls[0] != SCHEME:
        raise ValueError('scheme')
    return dict(l.split('=', 1) for l in ls[1:] if l)


def sign(sk: SigningKey, fields):
    payload = canonical_payload(fields)
    sig = sk.sign(payload.encode()).signature
    pk = bytes(sk.verify_key)
    blob = MAGIC + bytes([BLOB_VERSION, 0]) + pk + sig
    assert len(blob) == 101
    return dict(receipt=PREFIX + base64.urlsafe_b64encode(blob).decode().rstrip('='), payload=payload,
                payload_sha256=h(payload.encode()), signer_pubkey=pk.hex())


def verify_signature(receipt, payload):
    if not receipt.startswith(PREFIX):
        raise ValueError('bad receipt prefix')
    rest = receipt[len(PREFIX):]
    blob = base64.urlsafe_b64decode(rest + '=' * (-len(rest) % 4))
    if len(blob) != 101 or blob[:3] != MAGIC:
        raise ValueError('blob')
    pk, sig = blob[5:37], blob[37:101]
    try:
        VerifyKey(pk).verify(payload.encode(), sig)
    except BadSignatureError:
        raise ValueError('Ed25519 signature rejected')
    return pk.hex()


# ---------------- Merkle (RFC 6962 style) ----------------
def leaf_bytes(row, step, token, fp):
    return b'LXSTEP1' + row.to_bytes(4, 'little') + step.to_bytes(4, 'little') + token.to_bytes(4, 'little') + \
        (fp & 0xffffffffffffffff).to_bytes(8, 'little')


def lh(d):
    return hashlib.sha256(b'\x00' + d).digest()


def nh(a, b):
    return hashlib.sha256(b'\x01' + a + b).digest()


def mroot(leaves):
    if not leaves:
        return hashlib.sha256(b'').digest()
    lv = [lh(x) for x in leaves]
    return _root(lv)


def _root(hs):
    n = len(hs)
    if n == 1:
        return hs[0]
    k = 1
    while k * 2 < n:
        k *= 2
    return nh(_root(hs[:k]), _root(hs[k:]))


def mproof(leaves, i):
    """audit path for leaf i (RFC 6962 PATH)"""
    hs = [lh(x) for x in leaves]

    def path(m, D):
        n = len(D)
        if n == 1:
            return []
        k = 1
        while k * 2 < n:
            k *= 2
        if m < k:
            return path(m, D[:k]) + [_root(D[k:])]
        return path(m - k, D[k:]) + [_root(D[:k])]
    return [x.hex() for x in path(i, hs)]


def mverify(leaf, i, n, proof, root_hex):
    """RFC 9162 inclusion verification"""
    if i >= n:
        return False
    fn, sn = i, n - 1
    r = lh(leaf)
    for p in proof:
        p = bytes.fromhex(p)
        if sn == 0:
            return False
        if fn & 1 or fn == sn:
            r = nh(p, r)
            if not fn & 1:
                while True:
                    fn >>= 1; sn >>= 1
                    if fn & 1 or fn == 0:
                        break
        else:
            r = nh(r, p)
        fn >>= 1; sn >>= 1
    return sn == 0 and r.hex() == root_hex

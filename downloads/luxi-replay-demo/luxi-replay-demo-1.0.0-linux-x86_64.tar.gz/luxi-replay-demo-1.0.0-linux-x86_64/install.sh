#!/usr/bin/env bash
# luxi-replay-demo installer.   ./install.sh --gpu    or    ./install.sh --cpu
# Creates .venv/ inside this folder with Python 3.12 and pinned packages. Needs internet access. Never uses sudo.
# Optional: LUXI_PYTHON=/path/to/python3.12 ./install.sh --gpu   (use your own CPython 3.12 instead of uv)
set -euo pipefail
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$D"
die() { echo "error: $*" >&2; exit 2; }
MODE="${1:-}"
case "$MODE" in --gpu) M=gpu ;; --cpu) M=cpu ;; *) die "usage: ./install.sh --gpu   or   ./install.sh --cpu" ;; esac

echo "[1/5] checking this machine"
[ "$(uname -s)" = Linux ] || die "this package runs on Linux only (found $(uname -s))"
[ "$(uname -m)" = x86_64 ] || die "this package runs on x86_64 only (found $(uname -m))"
G="$(getconf GNU_LIBC_VERSION 2>/dev/null | awk '{print $2}')"
[ -n "$G" ] || die "GNU libc not found (musl/Alpine is not supported); glibc 2.34 or newer is required"
GA="${G%%.*}"; GB="${G#*.}"; GB="${GB%%.*}"
if [ "$GA" -lt 2 ] || { [ "$GA" -eq 2 ] && [ "$GB" -lt 34 ]; }; then
  die "glibc $G found; this build needs glibc 2.34 or newer (Ubuntu 22.04+, Debian 12+, RHEL/Rocky/Alma 9+, Amazon Linux 2023)"
fi
echo "  Linux x86_64, glibc $G"
if [ "$M" = gpu ]; then
  command -v nvidia-smi >/dev/null 2>&1 || die "--gpu: nvidia-smi not found, so no NVIDIA driver is installed. For the CPU replay run ./install.sh --cpu"
  nvidia-smi --query-gpu=name,compute_cap,memory.total,driver_version --format=csv,noheader 2>/dev/null | sed 's/^/  GPU: /' \
    || die "--gpu: nvidia-smi failed; the NVIDIA driver is not working"
  DRV="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1)"
  [ "${DRV%%.*}" -ge 570 ] 2>/dev/null || echo "  warning: driver $DRV is older than 570; the pinned PyTorch wheel (CUDA 12.9) may not start. Update the driver if luxi reports CUDA unavailable."
fi

echo "[2/5] checking package files against SHA256SUMS"
command -v sha256sum >/dev/null 2>&1 || die "sha256sum not found (install coreutils)"
sha256sum --quiet -c SHA256SUMS || die "package files do not match SHA256SUMS: download the package again"
echo "  all files match"

echo "[3/5] Python 3.12 environment in .venv/"
rm -rf .venv
if [ -n "${LUXI_PYTHON:-}" ]; then
  "$LUXI_PYTHON" -c 'import sys; assert sys.version_info[:2] == (3, 12) and sys.implementation.name == "cpython"' 2>/dev/null \
    || die "LUXI_PYTHON must be CPython 3.12 (the engine modules are compiled for CPython 3.12)"
  "$LUXI_PYTHON" -m venv .venv
  PIP=(.venv/bin/python -m pip install --disable-pip-version-check -q)
  .venv/bin/python -m pip install -q --upgrade pip
else
  UV="$(command -v uv || true)"
  if [ -z "$UV" ]; then
    command -v curl >/dev/null 2>&1 || die "curl not found; install curl, or set LUXI_PYTHON to a CPython 3.12"
    echo "  fetching uv 0.13.7 (Python installer from astral.sh) into .uv/"
    curl -LsSf https://astral.sh/uv/0.13.7/install.sh | env UV_INSTALL_DIR="$D/.uv" UV_NO_MODIFY_PATH=1 sh >/dev/null
    UV="$D/.uv/uv"
  fi
  "$UV" venv -q --python 3.12 .venv
  PIP=("$UV" pip install -q --python .venv/bin/python)
fi
.venv/bin/python -c 'import sys; print("  Python", sys.version.split()[0])'

echo "[4/5] installing pinned packages (PyTorch $M build; the GPU build is about 3 GB)"
if [ "$M" = gpu ]; then TI=https://download.pytorch.org/whl/cu129; TV="torch==2.13.0+cu129"; else TI=https://download.pytorch.org/whl/cpu; TV="torch==2.13.0+cpu"; fi
"${PIP[@]}" "$TV" --index-url "$TI"
"${PIP[@]}" -r "requirements-$M.txt"

echo "[5/5] checking the installation"
.venv/bin/python - "$M" <<'EOF'
import sys
sys.path.insert(0, 'engine')
import torch, numpy, nacl, safetensors, tokenizers  # noqa: F401
import lx_receipt  # noqa: F401
print('  torch', torch.__version__, '| numpy', numpy.__version__)
if sys.argv[1] == 'gpu':
    if torch.cuda.is_available():
        print('  CUDA OK:', torch.cuda.get_device_name(0), 'compute capability %d.%d' % torch.cuda.get_device_capability(0))
    else:
        print('  warning: PyTorch cannot see a CUDA GPU. "./luxi demo --device gpu" will stop with exit code 3 (it never falls back to the CPU).')
EOF
echo
echo "Installed. Next:"
echo "  ./luxi fetch-model                     # 8.7 GB from Hugging Face, once; every file is checked by sha256"
echo "  ./luxi inspect --device $M --check-weights"
echo "  ./luxi demo --device $M"

#!/usr/bin/env python3
"""luxi: command-line wrapper for the Luxi replay demo package (public source; the engine itself ships compiled).

  luxi inspect      [--device gpu|cpu] [--model DIR] [--check-weights]
  luxi fetch-model  [--model DIR]
  luxi demo         --device gpu|cpu [--model DIR] [--out DIR] [--threads N]
  luxi verify       RECORD --trusted-key KEY
  luxi compare      RECORD_A RECORD_B [--out FILE]
  luxi compare-dirs DIR_A DIR_B [--out FILE]
  luxi tamper-test  RECORD --trusted-key KEY
  luxi full-suite   --device gpu [--model DIR] [--out DIR] [--slots N] [--reserve-gb G]

Exit codes: 0 pass; 1 outputs differ / record rejected; 2 usage or input error; 3 requested device cannot run
(a GPU request never falls back to the CPU); 4 model files missing or checksum mismatch.
"""
import argparse, hashlib, json, os, platform, subprocess, sys, time

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENGINE = os.path.join(PKG, 'engine')
FIX = os.path.join(PKG, 'fixtures')
REF = os.path.join(PKG, 'reference')
sys.path.insert(0, os.path.join(PKG, 'verifier'))
import luxi_verify as LV  # noqa: E402

BUILD_INFO = json.load(open(os.path.join(PKG, 'BUILD_INFO.json')))
MODEL = BUILD_INFO['model']
SUPPORTED_CC = {tuple(map(int, k.split('.'))): v for k, v in BUILD_INFO['gpu']['compiled_for'].items()}
TINY = json.load(open(os.path.join(FIX, 'tiny', 'fixture.json')))
SUITE = json.load(open(os.path.join(FIX, 'full_suite', 'fixture.json')))
BENCH_KEY = open(os.path.join(REF, 'keys', 'luxi_benchmark_key_2026-11.pub')).read().split()[0]


class Fail(Exception):
    def __init__(self, code, msg):
        super().__init__(msg); self.code = code


def say(*a):
    print(*a, flush=True)


def file_sha(fn):
    s = hashlib.sha256()
    with open(fn, 'rb') as f:
        for b in iter(lambda: f.read(1 << 24), b''):
            s.update(b)
    return s.hexdigest()


def default_model_dir():
    return os.environ.get('LUXI_MODEL_DIR') or os.path.join(os.path.expanduser('~'), '.cache', 'luxi', 'models', MODEL['local_name'])


def cpu_name():
    try:
        return [l for l in open('/proc/cpuinfo') if 'model name' in l][0].split(':')[1].strip()
    except Exception:
        return platform.processor() or platform.machine()


def cpu_threads():
    """Usable CPU threads: the affinity mask, capped by a container CPU quota (cgroup v2 or v1).
    Using more threads than the quota allows makes the CPU path many times slower (it never changes the output)."""
    try:
        n = len(os.sched_getaffinity(0))
    except Exception:
        n = os.cpu_count() or 1
    quota = None
    try:
        q, p = open('/sys/fs/cgroup/cpu.max').read().split()
        if q != 'max':
            quota = int(q) / int(p)
    except Exception:
        for d in ('/sys/fs/cgroup/cpu', '/sys/fs/cgroup/cpu,cpuacct'):
            try:
                q = int(open(d + '/cpu.cfs_quota_us').read()); p = int(open(d + '/cpu.cfs_period_us').read())
                if q > 0 and p > 0:
                    quota = q / p
                break
            except Exception:
                pass
    if quota:
        n = min(n, max(1, int(quota)))
    return max(1, n)


# ---------------- model files ----------------
def check_weights(mdir, full=True):
    """Every pinned file must exist with the pinned size; with full=True the sha256 is checked too (cached by size+mtime).
    Returns (manifest {file: sha256} of the files the engine hashes into its record, seconds)."""
    t0 = time.time()
    if not os.path.isdir(mdir):
        raise Fail(4, f'model folder {mdir} not found. Run: ./luxi fetch-model --model {mdir}')
    cache_fn = os.path.join(mdir, '.luxi_verified.json')
    cache = json.load(open(cache_fn)) if os.path.exists(cache_fn) else {}
    for fn, (size, sha) in MODEL['files'].items():
        p = os.path.join(mdir, fn)
        if not os.path.exists(p):
            raise Fail(4, f'missing model file {fn} in {mdir}. Run: ./luxi fetch-model --model {mdir}')
        st = os.stat(p)
        if st.st_size != size:
            raise Fail(4, f'{fn}: size {st.st_size}, expected {size}. Re-run fetch-model.')
        c = cache.get(fn)
        if full and not (c and c[0] == st.st_size and c[1] == st.st_mtime_ns and c[2] == sha):
            got = file_sha(p)
            if got != sha:
                raise Fail(4, f'{fn}: sha256 {got}, expected {sha}. This is not the pinned weight file.')
            cache[fn] = [st.st_size, st.st_mtime_ns, got]
    extra = sorted(f for f in os.listdir(mdir) if f.endswith('.safetensors') and f not in MODEL['files'])
    if extra:
        raise Fail(4, f'unexpected weight files in {mdir}: {extra} (the engine loads every *.safetensors file)')
    if full:
        json.dump(cache, open(cache_fn, 'w'), indent=1)
        man = {fn: MODEL['files'][fn][1] for fn in MODEL['manifest_files']}
        json.dump(man, open(os.path.join(mdir, '.lx_manifest.json'), 'w'))   # what the engine records (verified above)
    return round(time.time() - t0, 2)


def cmd_fetch(a):
    mdir = a.model or default_model_dir()
    os.makedirs(mdir, exist_ok=True)
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        raise Fail(2, 'huggingface_hub is missing: run ./install.sh first')
    say(f'downloading {MODEL["repo"]} @ {MODEL["revision"]} to {mdir} (about 8.7 GB, once)')
    t0 = time.time()
    for fn in MODEL['files']:
        p = os.path.join(mdir, fn)
        if os.path.exists(p) and os.path.getsize(p) == MODEL['files'][fn][0]:
            continue
        hf_hub_download(MODEL['repo'], fn, revision=MODEL['revision'], local_dir=mdir)
    dl = round(time.time() - t0, 1)
    ck = check_weights(mdir, full=True)
    say(json.dumps(dict(model_dir=mdir, download_s=dl, checksum_s=ck, files_ok=sorted(MODEL['files'])), indent=1))
    return 0


# ---------------- devices ----------------
def gpu_check(min_gb):
    """GPU path must be runnable, or we stop. Never falls back to the CPU."""
    try:
        import torch
    except Exception as e:
        raise Fail(3, f'GPU requested, but PyTorch did not import ({e}). No CPU fallback. Run ./install.sh.')
    if not torch.cuda.is_available():
        why = 'no NVIDIA driver or GPU visible to PyTorch'
        try:
            why += ' (nvidia-smi: ' + subprocess.run(['nvidia-smi', '-L'], capture_output=True, text=True, timeout=20).stdout.strip()[:200] + ')'
        except Exception:
            why += ' (nvidia-smi not found)'
        raise Fail(3, f'GPU requested, but CUDA is not available: {why}. No CPU fallback. Use --device cpu for the CPU replay.')
    if torch.cuda.device_count() < 1:
        raise Fail(3, 'GPU requested, but no CUDA device is visible.')
    cc = torch.cuda.get_device_capability(0)
    name = torch.cuda.get_device_name(0)
    if cc not in SUPPORTED_CC:
        raise Fail(3, f'GPU {name} (compute capability {cc[0]}.{cc[1]}) is not supported by this build. Compiled for: '
                      + ', '.join(f'{k[0]}.{k[1]} ({v})' for k, v in sorted(SUPPORTED_CC.items())) + '. No CPU fallback.')
    tot = torch.cuda.get_device_properties(0).total_memory / 1e9
    if tot < min_gb:
        raise Fail(3, f'GPU {name} has {tot:.1f} GB; this command needs at least {min_gb} GB. No CPU fallback.')
    drv = ''
    try:
        drv = subprocess.run(['nvidia-smi', '--query-gpu=driver_version', '--format=csv,noheader'], capture_output=True,
                             text=True, timeout=20).stdout.strip().splitlines()[0]
    except Exception:
        pass
    return dict(name=name, compute_capability=f'{cc[0]}.{cc[1]}', memory_gb=round(tot, 1), driver=drv,
                torch=torch.__version__, torch_cuda=torch.version.cuda, arch=SUPPORTED_CC[cc])


def engine_env():
    # Fixed engine settings: the configuration the shipped engine files were validated with.
    os.environ['LX_GEMM'] = 'cublas'; os.environ['LX_GEMM_L'] = 'cublas'
    os.environ.setdefault('LX_V20', '2')
    if os.environ['LX_V20'] != '2':
        raise Fail(2, 'LX_V20 must be 2 in this package (the numerics mode the references were made with)')
    if ENGINE not in sys.path:
        sys.path.insert(0, ENGINE)


def signing_key(path):
    from nacl.signing import SigningKey
    if not path:
        d = os.path.join(PKG, '.luxi_state')
        try:
            os.makedirs(d, exist_ok=True); open(os.path.join(d, '.w'), 'w').close()
        except OSError:
            d = os.path.join(os.path.expanduser('~'), '.config', 'luxi')
            os.makedirs(d, exist_ok=True)
        path = os.path.join(d, 'demo_signing_key.hex')
    if os.path.exists(path):
        sk = SigningKey(bytes.fromhex(open(path).read().strip()))
    else:
        sk = SigningKey.generate()
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as f:
            f.write(bytes(sk).hex())
        say(f'created this installation\'s own signing key: {path} (private, never shipped)')
    return sk, path


# ---------------- commands ----------------
def cmd_inspect(a):
    engine_env()
    import lx_replay as R
    mdir = a.model or default_model_dir()
    out = dict(package=BUILD_INFO['package'], version=BUILD_INFO['version'], built=BUILD_INFO['built_utc'],
               build_sha256=R.build_sha(), engine_source_sha256=R.engine_sha(), engine_mode='LX_V20=' + os.environ['LX_V20'],
               compiled_for={f'{k[0]}.{k[1]}': v for k, v in sorted(SUPPORTED_CC.items())},
               host=dict(os=platform.platform(), cpu=cpu_name(), cpu_threads=cpu_threads(), python=platform.python_version()))
    dev = a.device or 'none'
    if dev == 'gpu':
        out['selected_device'] = dict(kind='gpu', **gpu_check(min_gb=16))
    elif dev == 'cpu':
        out['selected_device'] = dict(kind='cpu', name=cpu_name(), threads=cpu_threads())
    else:
        out['selected_device'] = 'none (pass --device gpu or --device cpu)'
    try:
        import torch
        out['torch'] = dict(version=torch.__version__, cuda_available=torch.cuda.is_available())
    except Exception as e:
        out['torch'] = f'not importable: {e}'
    ms = {}
    for fn, (size, sha) in MODEL['files'].items():
        p = os.path.join(mdir, fn)
        ms[fn] = dict(expected_sha256=sha, present=os.path.exists(p), size_ok=os.path.exists(p) and os.path.getsize(p) == size)
    if a.check_weights:
        try:
            out['weights_checksum_s'] = check_weights(mdir, full=True); out['weights_verified'] = True
        except Fail as e:
            out['weights_verified'] = False; out['weights_error'] = str(e)
    out['model'] = dict(repo=MODEL['repo'], revision=MODEL['revision'], license=MODEL['license'], dir=mdir, files=ms,
                        quantization=MODEL['quantization'])
    out['fixtures'] = dict(tiny={k: TINY[k] for k in ('job_id', 'job_sha256', 'prompt_tokens', 'sampling', 'n_samples', 'max_new', 'request_id', 'nov09_reference')},
                           full_suite={k: SUITE[k] for k in ('jobs', 'answers', 'tokens', 'jobs_sha256', 'reference')})
    out['trusted_keys'] = dict(nov09_benchmark_records=BENCH_KEY)
    print(json.dumps(out, indent=1))
    return 0


def cmd_demo(a):
    if a.device not in ('gpu', 'cpu'):
        raise Fail(2, '--device gpu or --device cpu is required')
    mdir = a.model or default_model_dir()
    out_dir = a.out or os.path.join(os.getcwd(), 'luxi_out')
    os.makedirs(out_dir, exist_ok=True)
    if a.device == 'gpu':
        devinfo = gpu_check(min_gb=16); dev = 'cuda'
    else:
        dev = 'cpu'; th = a.threads or cpu_threads()
        devinfo = dict(name=cpu_name(), threads=th)
        # set before torch and the engine load their OpenMP runtimes; passive waiting stops two idle
        # thread pools from spinning against a container CPU quota (speed only; outputs do not depend on it)
        os.environ['OMP_NUM_THREADS'] = str(th)
        os.environ.setdefault('OMP_WAIT_POLICY', 'PASSIVE')
    engine_env()
    say(f'[1/4] checking model files in {mdir}')
    ck_s = check_weights(mdir, full=True)
    import torch
    if dev == 'cpu':
        torch.set_num_threads(devinfo['threads'])
    import lx_replay as R
    from lx_engine import LxModel
    job = json.load(open(os.path.join(FIX, 'tiny', TINY['job_file'])))
    sk, kpath = signing_key(a.key)
    say(f'[2/4] loading the model on {devinfo["name"]} ({"GPU" if dev == "cuda" else "CPU"} path)')
    t0 = time.time()
    try:
        m = LxModel(mdir, dev=dev, maxB=TINY['maxB'], maxctx=TINY['maxctx'])
        if dev == 'cuda':
            torch.cuda.synchronize()
    except Exception as e:
        if dev == 'cuda':
            raise Fail(3, f'the GPU path failed to start on {devinfo["name"]}: {e}. No CPU fallback.')
        raise
    m.mdir = mdir
    load_s = round(time.time() - t0, 2)
    say(f'[3/4] running fixture {job["job_id"]}: {TINY["prompt_tokens"]}-token prompt, {TINY["max_new"]} sampled tokens, seed {job["sampling"]["seed"]}')
    t1 = time.time()
    try:
        B = R.run_job(m, job, dev, sk)
    except Exception as e:
        if dev == 'cuda':
            raise Fail(3, f'the GPU path failed during the run: {e}. No CPU fallback.')
        raise
    exec_s = round(time.time() - t1, 2)
    B.update(wall_s=exec_s, mode='run', maxB=TINY['maxB'], maxctx=TINY['maxctx'], tmax=m.tmax,
             package_timing=dict(weights_checksum_s=ck_s, model_load_s=load_s, execution_s=exec_s,
                                 note='execution_s = prefill + decode + sampling of this job; model download and load are excluded'))
    tag = ('gpu-' if dev == 'cuda' else 'cpu-') + ''.join(c if c.isalnum() else '_' for c in devinfo['name'])[:40]
    fn = os.path.join(out_dir, f'bundle_{job["job_id"]}_{tag}.json')
    json.dump(B, open(fn, 'w'))
    say('[4/4] checking the signed record')
    pub = bytes(sk.verify_key).hex()
    errs, f = LV.verify(B, pub)
    root = f[0].get('steps_merkle_root', '') if f else ''
    exp = TINY['nov09_reference']['steps_merkle_root_prefix']
    # the signed Nov 9 H100 NVL record of this replay (recovered Nov 10, shipped unchanged): check its signature
    # against the benchmark key, then compare every token id and per-step fingerprint with this run
    ref_fn = os.path.join(REF, 'nov09_h100_nvl_signed', 'short_replay', 'bundle_tiny_h100.json')
    ref_rec = LV.load_record(ref_fn)
    ref_errs, ref_f = LV.verify(ref_rec, BENCH_KEY)
    ref_root = ref_f[0].get('steps_merkle_root', '') if ref_f else ''
    C = LV.compare(ref_rec, B)
    full_match = bool(C['outputs_identical'] and not ref_errs and root and root == ref_root and root.startswith(exp))
    toks = B['calls'][0]['outputs'][0]
    text = None
    try:
        from tokenizers import Tokenizer
        tk = Tokenizer.from_file(os.path.join(mdir, 'tokenizer.json'))
        text = tk.decode(toks, skip_special_tokens=False)
        prompt_text = tk.decode(B['calls'][0]['prompt'], skip_special_tokens=False)
    except Exception:
        prompt_text = None
    res = dict(record=fn, device=devinfo, job_id=job['job_id'], generated_token_ids=toks, generated_text=text,
               prompt_text=prompt_text, steps=len(toks), steps_merkle_root=root,
               nov09_h100_reference_record=os.path.relpath(ref_fn, PKG), nov09_h100_reference_root=ref_root,
               nov09_reference_signature_verified=not ref_errs, nov09_first_mismatch=C['first_mismatch'],
               answers_identical_to_nov09=C['answers_identical'], matches_nov09_reference=full_match,
               record_verifies=not errs, verify_errors=errs[:3], signer_public_key=pub, signing_key_file=kpath,
               timing=dict(weights_checksum_s=ck_s, model_load_s=load_s, execution_s=exec_s, **B['timing']),
               build_sha256=B['build']['build_sha256'], engine_source_sha256=B['engine_sha256'])
    # readable summary: named so that the bundle_*.json patterns in the README match only the signed record
    json.dump(res, open(os.path.join(out_dir, f'summary_{job["job_id"]}_{tag}.json'), 'w'), indent=1)
    say(json.dumps(res, indent=1))
    say('\nRESULT: ' + (f'SAME OUTPUTS as the signed Nov 9 H100 NVL record: all {len(toks)} token ids and per-step logit\n'
                        f'        fingerprints are identical (step Merkle root {root[:16]}...). Reference record:\n'
                        f'        {os.path.relpath(ref_fn, PKG)}, signature checked against the benchmark key.'
                        if res['matches_nov09_reference'] and not errs else
                        f'NO MATCH with the signed Nov 9 H100 NVL record (first difference: {C["first_mismatch"]}),\n'
                        '        or a record failed to verify.'))
    say(f'verify offline:  ./luxi verify {fn} --trusted-key {pub}')
    say(f'compare runs:    ./luxi compare RECORD_FROM_OTHER_MACHINE.json {fn}')
    say(f'vs Nov 9 record: ./luxi compare {os.path.relpath(ref_fn, os.getcwd())} {fn}')
    return 0 if (res['matches_nov09_reference'] and not errs) else 1


def cmd_full(a):
    if a.device != 'gpu':
        raise Fail(2, 'The full 136-answer suite runs on a GPU only (--device gpu). The CPU path in this package covers the '
                      'short 32-token replay (luxi demo --device cpu); no CPU full-suite result is claimed.')
    devinfo = gpu_check(min_gb=22)
    mdir = a.model or default_model_dir()
    out_dir = os.path.abspath(a.out or os.path.join(os.getcwd(), 'luxi_full_suite'))
    os.makedirs(out_dir, exist_ok=True)
    engine_env()
    ck_s = check_weights(mdir, full=True)
    sk, kpath = signing_key(a.key)
    rg = a.reserve_gb if a.reserve_gb else (19.0 if devinfo['memory_gb'] < 40 else 15.0)
    slots = a.slots or 32
    jobs = os.path.join(FIX, 'full_suite', 'jobs', '*.json')
    rec = os.path.join(out_dir, 'records')
    say(f'full suite: {SUITE["jobs"]} problems x 8 samples = {SUITE["answers"]} answers, up to 16,384 tokens each, on {devinfo["name"]} '
        f'({slots} slots, reserve {rg} GB). Records: {rec}')
    argv = ['lx_evalrun', '--model', mdir, '--jobs', jobs, '--outdir', rec, '--key', kpath, '--slots', str(slots),
            '--maxctx', str(SUITE['maxctx']), '--pages', 'auto', '--reserve_gb', str(rg), '--log', os.path.join(out_dir, 'run.log')]
    t0 = time.time()
    sys.argv = argv
    try:
        import lx_evalrun  # noqa: F401  (runs the suite on import)
    except SystemExit:
        pass
    except Exception as e:
        raise Fail(3, f'the GPU path failed during the full suite on {devinfo["name"]}: {e}. No CPU fallback.')
    wall = round(time.time() - t0, 1)
    ref = os.path.join(REF, 'nov09_h100_nvl_signed', 'full_suite')
    S = LV.compare_dirs(ref, rec)
    import glob as _g
    summ = sorted(_g.glob(os.path.join(rec, 'evalrun_summary_*.json')))
    run = json.load(open(summ[-1])) if summ else {}
    bad = [LV.verify(json.load(open(f)), bytes(sk.verify_key).hex())[0] for f in sorted(_g.glob(os.path.join(rec, 'bundle_*.json')))]
    res = dict(device=devinfo, records=rec, reference=ref, wall_s=wall, weights_checksum_s=ck_s, run=run,
               own_records_verify=all(not e for e in bad), signer_public_key=bytes(sk.verify_key).hex(),
               vs_nov09_h100=S)
    json.dump(res, open(os.path.join(out_dir, 'full_suite_result.json'), 'w'), indent=1)
    say(json.dumps({k: v for k, v in res.items() if k != 'run'}, indent=1, default=str))
    ok = S['all_outputs_identical'] and S['answers'] == SUITE['answers'] and S['tokens_b'] == SUITE['tokens'] and res['own_records_verify']
    say('\nRESULT: ' + (f'{S["answers_identical"]}/{SUITE["answers"]} answers and {S["tokens_b"]:,} tokens identical to the signed Nov 9 H100 NVL records'
                        if ok else 'MISMATCH against the Nov 9 records: see full_suite_result.json'))
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(prog='luxi', description='Luxi replay demo (closed-binary engine, public wrapper).')
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('inspect'); p.add_argument('--device', choices=['gpu', 'cpu']); p.add_argument('--model'); p.add_argument('--check-weights', action='store_true')
    p = sp.add_parser('fetch-model'); p.add_argument('--model')
    p = sp.add_parser('demo'); p.add_argument('--device', choices=['gpu', 'cpu'], required=True); p.add_argument('--model')
    p.add_argument('--out'); p.add_argument('--threads', type=int); p.add_argument('--key', help='signing key file (default: this installation\'s own key)')
    p = sp.add_parser('full-suite'); p.add_argument('--device', choices=['gpu', 'cpu'], required=True); p.add_argument('--model')
    p.add_argument('--out'); p.add_argument('--slots', type=int); p.add_argument('--reserve-gb', type=float); p.add_argument('--key')
    for name in ('verify', 'compare', 'compare-dirs', 'tamper-test'):
        sp.add_parser(name, add_help=False)
    if len(sys.argv) > 1 and sys.argv[1] in ('verify', 'compare', 'compare-dirs', 'tamper-test'):
        return LV.main(sys.argv[1:])
    a = ap.parse_args()
    try:
        return dict(inspect=cmd_inspect, demo=cmd_demo, **{'fetch-model': cmd_fetch, 'full-suite': cmd_full})[a.cmd](a)
    except Fail as e:
        sys.stderr.write(f'error: {e}\n')
        return e.code


if __name__ == '__main__':
    sys.exit(main())
